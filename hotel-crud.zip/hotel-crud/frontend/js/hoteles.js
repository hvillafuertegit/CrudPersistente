let idAEliminar = null;

async function cargarHoteles() {
  const contenedor = document.getElementById('tabla-hoteles-contenedor');
  try {
    const hoteles = await apiRequest('/hoteles');
    document.getElementById('contador-hoteles').textContent =
      `${hoteles.length} hotel(es) registrado(s)`;

    if (hoteles.length === 0) {
      contenedor.innerHTML = '<p class="vacio">Aún no hay hoteles registrados.</p>';
      return;
    }

    const filas = hoteles.map(h => `
      <tr>
        <td>${h.id}</td>
        <td>${escapeHtml(h.nombre)}</td>
        <td>${escapeHtml(h.ciudad)}</td>
        <td>${'★'.repeat(h.categoria)}</td>
        <td>${h.telefono ? escapeHtml(h.telefono) : '-'}</td>
        <td class="acciones">
          <button onclick='abrirModalEditar(${JSON.stringify(h)})'>Editar</button>
          <button class="eliminar" onclick="abrirModalEliminar(${h.id})">Eliminar</button>
        </td>
      </tr>`).join('');

    contenedor.innerHTML = `
      <table>
        <thead>
          <tr><th>ID</th><th>Nombre</th><th>Ciudad</th><th>Categoría</th><th>Teléfono</th><th>Acciones</th></tr>
        </thead>
        <tbody>${filas}</tbody>
      </table>`;
  } catch (err) {
    contenedor.innerHTML = `<p class="vacio">No se pudo cargar la información: ${err.message}</p>`;
    mostrarToast(err.message, 'error');
  }
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function abrirModalCrear() {
  document.getElementById('modal-titulo').textContent = 'Nuevo hotel';
  document.getElementById('form-hotel').reset();
  document.getElementById('hotel-id').value = '';
  limpiarErrores();
  document.getElementById('modal-hotel').classList.add('abierto');
}

function abrirModalEditar(hotel) {
  document.getElementById('modal-titulo').textContent = 'Editar hotel';
  document.getElementById('hotel-id').value = hotel.id;
  document.getElementById('hotel-nombre').value = hotel.nombre;
  document.getElementById('hotel-ciudad').value = hotel.ciudad;
  document.getElementById('hotel-direccion').value = hotel.direccion || '';
  document.getElementById('hotel-categoria').value = hotel.categoria;
  document.getElementById('hotel-telefono').value = hotel.telefono || '';
  limpiarErrores();
  document.getElementById('modal-hotel').classList.add('abierto');
}

function cerrarModal() {
  document.getElementById('modal-hotel').classList.remove('abierto');
}

function limpiarErrores() {
  document.querySelectorAll('.error-msg').forEach(e => (e.style.display = 'none'));
}

function validarFormulario() {
  limpiarErrores();
  let valido = true;
  const nombre = document.getElementById('hotel-nombre').value.trim();
  const ciudad = document.getElementById('hotel-ciudad').value.trim();
  const categoria = Number(document.getElementById('hotel-categoria').value);

  if (!nombre) { document.getElementById('err-nombre').style.display = 'block'; valido = false; }
  if (!ciudad) { document.getElementById('err-ciudad').style.display = 'block'; valido = false; }
  if (!categoria || categoria < 1 || categoria > 5) {
    document.getElementById('err-categoria').style.display = 'block';
    valido = false;
  }
  return valido;
}

document.getElementById('form-hotel').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!validarFormulario()) return;

  const id = document.getElementById('hotel-id').value;
  const payload = {
    nombre: document.getElementById('hotel-nombre').value.trim(),
    ciudad: document.getElementById('hotel-ciudad').value.trim(),
    direccion: document.getElementById('hotel-direccion').value.trim(),
    categoria: Number(document.getElementById('hotel-categoria').value),
    telefono: document.getElementById('hotel-telefono').value.trim(),
  };

  try {
    if (id) {
      await apiRequest(`/hoteles/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
      mostrarToast('Hotel actualizado correctamente.');
    } else {
      await apiRequest('/hoteles', { method: 'POST', body: JSON.stringify(payload) });
      mostrarToast('Hotel creado correctamente.');
    }
    cerrarModal();
    cargarHoteles();
  } catch (err) {
    mostrarToast(err.message, 'error');
  }
});

function abrirModalEliminar(id) {
  idAEliminar = id;
  document.getElementById('modal-eliminar').classList.add('abierto');
}

function cerrarModalEliminar() {
  idAEliminar = null;
  document.getElementById('modal-eliminar').classList.remove('abierto');
}

async function confirmarEliminar() {
  try {
    await apiRequest(`/hoteles/${idAEliminar}`, { method: 'DELETE' });
    mostrarToast('Hotel eliminado correctamente.');
    cerrarModalEliminar();
    cargarHoteles();
  } catch (err) {
    mostrarToast(err.message, 'error');
    cerrarModalEliminar();
  }
}

cargarHoteles();
