const express = require('express');
const router = express.Router();
const pool = require('../db');

function validarHotel(body) {
  const errores = [];
  if (!body.nombre || !body.nombre.trim()) errores.push('El campo "nombre" es obligatorio.');
  if (!body.ciudad || !body.ciudad.trim()) errores.push('El campo "ciudad" es obligatorio.');
  if (
    body.categoria === undefined ||
    body.categoria === null ||
    isNaN(Number(body.categoria)) ||
    Number(body.categoria) < 1 ||
    Number(body.categoria) > 5
  ) {
    errores.push('El campo "categoria" debe ser un número entre 1 y 5.');
  }
  return errores;
}

/**
 * @openapi
 * /api/hoteles:
 *   get:
 *     summary: Obtener todos los hoteles
 *     tags: [Hoteles]
 *     responses:
 *       200:
 *         description: Lista de hoteles
 *   post:
 *     summary: Crear un nuevo hotel
 *     tags: [Hoteles]
 *     requestBody:
 *       required: true
 *     responses:
 *       201:
 *         description: Hotel creado
 *       400:
 *         description: Datos inválidos
 */
router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM hoteles ORDER BY id DESC');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error de conexión con la base de datos.' });
  }
});

router.post('/', async (req, res) => {
  const errores = validarHotel(req.body);
  if (errores.length) return res.status(400).json({ error: errores.join(' ') });

  const { nombre, ciudad, direccion, categoria, telefono } = req.body;
  try {
    const result = await pool.query(
      `INSERT INTO hoteles (nombre, ciudad, direccion, categoria, telefono)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [nombre.trim(), ciudad.trim(), direccion || null, categoria, telefono || null]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error de conexión con la base de datos.' });
  }
});

/**
 * @openapi
 * /api/hoteles/{id}:
 *   get:
 *     summary: Obtener un hotel por ID
 *     tags: [Hoteles]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Hotel encontrado }
 *       404: { description: Hotel no encontrado }
 *   put:
 *     summary: Actualizar un hotel
 *     tags: [Hoteles]
 *     responses:
 *       200: { description: Hotel actualizado }
 *       404: { description: Hotel no encontrado }
 *   delete:
 *     summary: Eliminar un hotel
 *     tags: [Hoteles]
 *     responses:
 *       200: { description: Hotel eliminado }
 *       404: { description: Hotel no encontrado }
 */
router.get('/:id', async (req, res) => {
  const { id } = req.params;
  if (isNaN(Number(id))) return res.status(400).json({ error: 'El ID debe ser numérico.' });
  try {
    const result = await pool.query('SELECT * FROM hoteles WHERE id = $1', [id]);
    if (result.rows.length === 0)
      return res.status(404).json({ error: 'Hotel no encontrado.' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error de conexión con la base de datos.' });
  }
});

router.put('/:id', async (req, res) => {
  const { id } = req.params;
  if (isNaN(Number(id))) return res.status(400).json({ error: 'El ID debe ser numérico.' });

  const errores = validarHotel(req.body);
  if (errores.length) return res.status(400).json({ error: errores.join(' ') });

  const { nombre, ciudad, direccion, categoria, telefono } = req.body;
  try {
    const result = await pool.query(
      `UPDATE hoteles SET nombre=$1, ciudad=$2, direccion=$3, categoria=$4, telefono=$5
       WHERE id=$6 RETURNING *`,
      [nombre.trim(), ciudad.trim(), direccion || null, categoria, telefono || null, id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ error: 'Hotel no encontrado.' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error de conexión con la base de datos.' });
  }
});

router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  if (isNaN(Number(id))) return res.status(400).json({ error: 'El ID debe ser numérico.' });
  try {
    const result = await pool.query('DELETE FROM hoteles WHERE id=$1 RETURNING *', [id]);
    if (result.rows.length === 0)
      return res.status(404).json({ error: 'Hotel no encontrado.' });
    res.json({ mensaje: 'Hotel eliminado correctamente.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error de conexión con la base de datos.' });
  }
});

/**
 * @openapi
 * /api/hoteles/{id}/habitaciones:
 *   get:
 *     summary: Obtener las habitaciones de un hotel específico
 *     tags: [Hoteles]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200: { description: Lista de habitaciones del hotel }
 *       404: { description: Hotel no encontrado }
 */
router.get('/:id/habitaciones', async (req, res) => {
  const { id } = req.params;
  if (isNaN(Number(id))) return res.status(400).json({ error: 'El ID debe ser numérico.' });
  try {
    const hotel = await pool.query('SELECT id FROM hoteles WHERE id=$1', [id]);
    if (hotel.rows.length === 0)
      return res.status(404).json({ error: 'Hotel no encontrado.' });

    const result = await pool.query(
      'SELECT * FROM habitaciones WHERE hotel_id=$1 ORDER BY numero',
      [id]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error de conexión con la base de datos.' });
  }
});

module.exports = router;
