# Hotel Manager — CRUD Persistente

## 1. Nombre del proyecto
**Hotel Manager**: aplicación web para la administración de hoteles y sus habitaciones.

## 2. Problema que resuelve
Un pequeño hotel o cadena hotelera necesita un sistema simple para llevar el control de
sus **hoteles** (sede, ciudad, categoría) y de las **habitaciones** de cada uno (tipo,
precio por noche y estado: disponible, ocupada o en mantenimiento). Hoy esa información
se maneja en hojas de cálculo o en papel, lo que genera datos desactualizados y errores.
Esta aplicación centraliza esa información en una base de datos real, accesible desde una
interfaz web sencilla, permitiendo crear, consultar, editar y eliminar registros de forma
persistente (los datos se mantienen aunque se cierre o reinicie la aplicación).

## 3. Tecnologías utilizadas
| Capa        | Tecnología |
|-------------|------------|
| Frontend    | HTML5 + CSS3 + JavaScript (Vanilla, sin framework) |
| Backend/API | Node.js + Express (REST) |
| Base de datos | PostgreSQL 15 (contenedor Docker) |
| Documentación de API | Swagger / OpenAPI (swagger-jsdoc + swagger-ui-express) |
| Contenedores | Docker + Docker Compose |

**Entidades relacionadas:** `hoteles` (1) → `habitaciones` (N). Cada habitación pertenece
a un hotel (`hotel_id` como llave foránea, con `ON DELETE CASCADE`).

## 4. Estructura del repositorio
```
/frontend      → interfaz web (HTML/CSS/JS)
/backend       → API REST (Node.js + Express)
/database      → schema.sql (DDL de PostgreSQL con datos de ejemplo)
docker-compose.yml → levanta la base de datos PostgreSQL
README.md
```

## 5. Cómo ejecutar el proyecto

### Requisitos previos
- Node.js 18 o superior
- Docker y Docker Compose

### Paso 1: Levantar la base de datos (Docker)
Desde la raíz del repositorio:
```bash
docker compose up -d
```
Esto crea un contenedor PostgreSQL en el puerto `5432`, con la base de datos `hotel_db`
y ejecuta automáticamente `database/schema.sql` (crea las tablas y algunos registros
de ejemplo).

Verificar que el contenedor está corriendo:
```bash
docker ps
```

### Paso 2: Ejecutar el backend
```bash
cd backend
cp .env.example .env
npm install
npm start
```
El servidor queda disponible en: **http://localhost:3000**
La documentación Swagger en: **http://localhost:3000/api-docs**

Si la base de datos usa otro host, usuario o contraseña, edita el archivo `.env`.

### Paso 3: Ejecutar el frontend
El frontend es HTML/CSS/JS puro, no requiere instalación. Basta con abrir el archivo
`frontend/index.html` en el navegador, o servirlo con cualquier servidor estático, por
ejemplo:
```bash
cd frontend
npx serve .
```
Luego abrir **http://localhost:3000** (o el puerto que indique `serve`) — si el backend
corre también en el puerto 3000, usar otro puerto para el frontend, por ejemplo `npx serve . -l 5173`.

> El frontend consume el backend en `http://localhost:3000/api` (definido en
> `frontend/js/api.js`, variable `API_BASE`). Ajustar esa constante si el backend corre
> en otra URL.

## 6. Endpoints disponibles (Swagger)

La documentación interactiva completa está en `http://localhost:3000/api-docs`.
Resumen de endpoints:

### Hoteles
| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/api/hoteles` | Listar todos los hoteles |
| GET | `/api/hoteles/:id` | Obtener un hotel por ID |
| POST | `/api/hoteles` | Crear un hotel |
| PUT | `/api/hoteles/:id` | Actualizar un hotel |
| DELETE | `/api/hoteles/:id` | Eliminar un hotel |
| GET | `/api/hoteles/:id/habitaciones` | Listar las habitaciones de un hotel |

### Habitaciones
| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/api/habitaciones` | Listar todas las habitaciones |
| GET | `/api/habitaciones/:id` | Obtener una habitación por ID |
| POST | `/api/habitaciones` | Crear una habitación |
| PUT | `/api/habitaciones/:id` | Actualizar una habitación |
| DELETE | `/api/habitaciones/:id` | Eliminar una habitación |

### Salud
| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/api/health` | Verifica la conexión con la base de datos |

## 7. Manejo de errores
La API responde con códigos y mensajes claros ante:
- `400` — datos inválidos o campos obligatorios vacíos (validación en backend y frontend).
- `404` — registro inexistente (hotel o habitación) o intento de eliminar un ID que no existe.
- `500` — error de conexión con la base de datos u otro error interno.

El frontend muestra estos mensajes mediante notificaciones (*toasts*) y validación en los
formularios antes de enviar la petición.
