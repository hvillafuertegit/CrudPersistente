// Ajusta esta URL si el backend corre en otro host/puerto
const API_BASE = 'http://localhost:3000/api';

async function apiRequest(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });

  let data = null;
  try {
    data = await res.json();
  } catch (e) {
    // sin cuerpo (por ejemplo, error de red)
  }

  if (!res.ok) {
    const mensaje = (data && data.error) || `Error ${res.status}`;
    throw new Error(mensaje);
  }
  return data;
}

function mostrarToast(mensaje, tipo = 'exito') {
  let contenedor = document.querySelector('.toast-contenedor');
  if (!contenedor) {
    contenedor = document.createElement('div');
    contenedor.className = 'toast-contenedor';
    document.body.appendChild(contenedor);
  }
  const toast = document.createElement('div');
  toast.className = `toast ${tipo}`;
  toast.textContent = mensaje;
  contenedor.appendChild(toast);
  setTimeout(() => toast.remove(), 3500);
}
