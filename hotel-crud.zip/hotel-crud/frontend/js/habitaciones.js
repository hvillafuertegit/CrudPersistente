let idAEliminar = null;
let hotelesCache = [];

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

async function cargarHotelesSelect() {
  try {
    hotelesCache = await apiRequest('/hoteles');
    const select = document.getElementById('habitacion-hotel');
    select.innerHTML = hotelesCache
      .map(h => `<option value="${h.id}">${escapeHtml(h.nombre)}</option>`)
      .join('');
  } catch (err) {
    mostrarToast('No se pudieron cargar los hoteles: ' + err.message, 'error');
  }
}

async function cargarHabitaciones() {
  const contenedor = document.getElementById('tabla-habitaciones-contenedor');
  try {
    const habitaciones = await apiRequest('/habitaciones');
    document.getElementById('contador-habitaciones').textContent =
      `${habitaciones.length} habitación(es) registrada(s)`;

    if (habitaciones.length === 0) {
      contenedor.innerHTML = '<p class="vacio">Aún no hay habitaciones registradas.</p>';
      return;
    }

    const filas = habitaciones.map(h => `
      <tr>
        <td>${h.id}</td>
        <td>${escapeHtml(h.hotel_nombre)}</td>
        <td>${escapeHtml(h.numero)}</td>
        <td>${escapeHtml(h.tipo)}</td>
        <td>Q ${Number(h.precio_noche).toFixed(2)}</td>
        <td><span class="estado-pill estado-${h.estado}">${h.estado}</span></td>
        <td class="acciones">
          <button onclick='abrirModalEditar(${JSON.stringify(h)})'>Editar</button>
          <button class="eliminar" onclick="abrirModalEliminar(${h.id})">Eliminar</button>
        </td>
      </tr>`).join('');

    contenedor.innerHTML = `
      <table>
        <thead>
          <tr><th>ID</th><th>Hotel</th><th>Número</th><th>Tipo</th><th>Precio/noche</th><th>Estado</th><th>Acciones</th></tr>
        </thead>
        <tbody>${filas}</tbody>
      </table>`;
  } catch (err) {
    contenedor.innerHTML = `<p class="vacio">No se pudo cargar la información: ${err.message}</p>`;
    mostrarToast(err.message, 'error');
  }
}

function abrirModalCrear() {
  document.getElementById('modal-titulo').textContent = 'Nueva habitación';
  document.getElementById('form-habitacion').reset();
  document.getElementById('habitacion-id').value = '';
  limpiarErrores();
  document.getElementById('modal-habitacion').classList.add('abierto');
}

function abrirModalEditar(hab) {
  document.getElementById('modal-titulo').textContent = 'Editar habitación';
  document.getElementById('habitacion-id').value = hab.id;
  document.getElementById('habitacion-hotel').value = hab.hotel_id;
  document.getElementById('habitacion-numero').value = hab.numero;
  document.getElementById('habitacion-tipo').value = hab.tipo;
  document.getElementById('habitacion-precio').value = hab.precio_noche;
  document.getElementById('habitacion-estado').value = hab.estado;
  limpiarErrores();
  document.getElementById('modal-habitacion').classList.add('abierto');
}

function cerrarModal() {
  document.getElementById('modal-habitacion').classList.remove('abierto');
}

function limpiarErrores() {
  document.querySelectorAll('.error-msg').forEach(e => (e.style.display = 'none'));
}

function validarFormulario() {
  limpiarErrores();
  let valido = true;
  const hotel = document.getElementById('habitacion-hotel').value;
  const numero = document.getElementById('habitacion-numero').value.trim();
  const precio = Number(document.getElementById('habitacion-precio').value);

  if (!hotel) { document.getElementById('err-hotel').style.display = 'block'; valido = false; }
  if (!numero) { document.getElementById('err-numero').style.display = 'block'; valido = false; }
  if (isNaN(precio) || precio < 0) {
    document.getElementById('err-precio').style.display = 'block';
    valido = false;
  }
  return valido;
}

document.getElementById('form-habitacion').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!validarFormulario()) return;

  const id = document.getElementById('habitacion-id').value;
  const payload = {
    hotel_id: Number(document.getElementById('habitacion-hotel').value),
    numero: document.getElementById('habitacion-numero').value.trim(),
    tipo: document.getElementById('habitacion-tipo').value,
    precio_noche: Number(document.getElementById('habitacion-precio').value),
    estado: document.getElementById('habitacion-estado').value,
  };

  try {
    if (id) {
      await apiRequest(`/habitaciones/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
      mostrarToast('Habitación actualizada correctamente.');
    } else {
      await apiRequest('/habitaciones', { method: 'POST', body: JSON.stringify(payload) });
      mostrarToast('Habitación creada correctamente.');
    }
    cerrarModal();
    cargarHabitaciones();
  } catch (err) {
    mostrarToast(err.message, 'error');
  }
});

function abrirModalEliminar(id) {
  idAEliminar = id;
  document.getElementById('modal-eliminar').classList.add('abierto');
}

function cerrarModalEliminar() {
  idAEliminar = null;
  document.getElementById('modal-eliminar').classList.remove('abierto');
}

async function confirmarEliminar() {
  try {
    await apiRequest(`/habitaciones/${idAEliminar}`, { method: 'DELETE' });
    mostrarToast('Habitación eliminada correctamente.');
    cerrarModalEliminar();
    cargarHabitaciones();
  } catch (err) {
    mostrarToast(err.message, 'error');
    cerrarModalEliminar();
  }
}

cargarHotelesSelect();
cargarHabitaciones();
