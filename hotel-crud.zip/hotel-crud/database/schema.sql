
DROP TABLE IF EXISTS habitaciones CASCADE;
DROP TABLE IF EXISTS hoteles CASCADE;

CREATE TABLE hoteles (
    id              SERIAL PRIMARY KEY,
    nombre          VARCHAR(120) NOT NULL,
    ciudad          VARCHAR(80)  NOT NULL,
    direccion       VARCHAR(200),
    categoria       SMALLINT     NOT NULL CHECK (categoria BETWEEN 1 AND 5), -- estrellas
    telefono        VARCHAR(30),
    creado_en       TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE TABLE habitaciones (
    id              SERIAL PRIMARY KEY,
    hotel_id        INTEGER      NOT NULL REFERENCES hoteles(id) ON DELETE CASCADE,
    numero          VARCHAR(10)  NOT NULL,
    tipo            VARCHAR(20)  NOT NULL CHECK (tipo IN ('Individual','Doble','Suite','Familiar')),
    precio_noche    NUMERIC(10,2) NOT NULL CHECK (precio_noche >= 0),
    estado          VARCHAR(20)  NOT NULL DEFAULT 'Disponible'
                        CHECK (estado IN ('Disponible','Ocupada','Mantenimiento')),
    creado_en       TIMESTAMP    NOT NULL DEFAULT NOW(),
    UNIQUE (hotel_id, numero)
);

CREATE INDEX idx_habitaciones_hotel_id ON habitaciones(hotel_id);

INSERT INTO hoteles (nombre, ciudad, direccion, categoria, telefono) VALUES
('Hotel Real Huehueteco', 'Huehuetenango', '4a Calle 3-20 Zona 1', 4, '77641234'),
('Posada del Valle', 'Antigua Guatemala', '5a Avenida Norte #12', 3, '78321122'),
('Gran Hotel Central', 'Ciudad de Guatemala', '9a Calle 5-30 Zona 9', 5, '24551000');

INSERT INTO habitaciones (hotel_id, numero, tipo, precio_noche, estado) VALUES
(1, '101', 'Individual', 250.00, 'Disponible'),
(1, '102', 'Doble', 380.00, 'Ocupada'),
(2, '201', 'Suite', 650.00, 'Disponible'),
(3, '301', 'Familiar', 520.00, 'Mantenimiento');
