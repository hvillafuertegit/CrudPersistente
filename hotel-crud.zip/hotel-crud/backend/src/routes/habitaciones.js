const express = require('express');
const router = express.Router();
const pool = require('../db');

const TIPOS_VALIDOS = ['Individual', 'Doble', 'Suite', 'Familiar'];
const ESTADOS_VALIDOS = ['Disponible', 'Ocupada', 'Mantenimiento'];

function validarHabitacion(body) {
  const errores = [];
  if (!body.hotel_id || isNaN(Number(body.hotel_id)))
    errores.push('El campo "hotel_id" es obligatorio y debe ser numérico.');
  if (!body.numero || !body.numero.trim()) errores.push('El campo "numero" es obligatorio.');
  if (!TIPOS_VALIDOS.includes(body.tipo))
    errores.push(`El campo "tipo" debe ser uno de: ${TIPOS_VALIDOS.join(', ')}.`);
  if (body.precio_noche === undefined || isNaN(Number(body.precio_noche)) || Number(body.precio_noche) < 0)
    errores.push('El campo "precio_noche" debe ser un número mayor o igual a 0.');
  if (body.estado && !ESTADOS_VALIDOS.includes(body.estado))
    errores.push(`El campo "estado" debe ser uno de: ${ESTADOS_VALIDOS.join(', ')}.`);
  return errores;
}

/**
 * @openapi
 * /api/habitaciones:
 *   get:
 *     summary: Obtener todas las habitaciones
 *     tags: [Habitaciones]
 *     responses:
 *       200: { description: Lista de habitaciones }
 *   post:
 *     summary: Crear una nueva habitación
 *     tags: [Habitaciones]
 *     responses:
 *       201: { description: Habitación creada }
 *       400: { description: Datos inválidos }
 *       404: { description: Hotel no encontrado }
 */
router.get('/', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT h.*, ho.nombre AS hotel_nombre
       FROM habitaciones h
       JOIN hoteles ho ON ho.id = h.hotel_id
       ORDER BY h.id DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error de conexión con la base de datos.' });
  }
});

router.post('/', async (req, res) => {
  const errores = validarHabitacion(req.body);
  if (errores.length) return res.status(400).json({ error: errores.join(' ') });

  const { hotel_id, numero, tipo, precio_noche, estado } = req.body;
  try {
    const hotel = await pool.query('SELECT id FROM hoteles WHERE id=$1', [hotel_id]);
    if (hotel.rows.length === 0)
      return res.status(404).json({ error: 'El hotel indicado no existe.' });

    const result = await pool.query(
      `INSERT INTO habitaciones (hotel_id, numero, tipo, precio_noche, estado)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [hotel_id, numero.trim(), tipo, precio_noche, estado || 'Disponible']
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    if (err.code === '23505')
      return res.status(400).json({ error: 'Ya existe una habitación con ese número en el hotel.' });
    console.error(err);
    res.status(500).json({ error: 'Error de conexión con la base de datos.' });
  }
});

/**
 * @openapi
 * /api/habitaciones/{id}:
 *   get:
 *     summary: Obtener una habitación por ID
 *     tags: [Habitaciones]
 *     responses:
 *       200: { description: Habitación encontrada }
 *       404: { description: Habitación no encontrada }
 *   put:
 *     summary: Actualizar una habitación
 *     tags: [Habitaciones]
 *     responses:
 *       200: { description: Habitación actualizada }
 *       404: { description: Habitación no encontrada }
 *   delete:
 *     summary: Eliminar una habitación
 *     tags: [Habitaciones]
 *     responses:
 *       200: { description: Habitación eliminada }
 *       404: { description: Habitación no encontrada }
 */
router.get('/:id', async (req, res) => {
  const { id } = req.params;
  if (isNaN(Number(id))) return res.status(400).json({ error: 'El ID debe ser numérico.' });
  try {
    const result = await pool.query('SELECT * FROM habitaciones WHERE id=$1', [id]);
    if (result.rows.length === 0)
      return res.status(404).json({ error: 'Habitación no encontrada.' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error de conexión con la base de datos.' });
  }
});

router.put('/:id', async (req, res) => {
  const { id } = req.params;
  if (isNaN(Number(id))) return res.status(400).json({ error: 'El ID debe ser numérico.' });

  const errores = validarHabitacion(req.body);
  if (errores.length) return res.status(400).json({ error: errores.join(' ') });

  const { hotel_id, numero, tipo, precio_noche, estado } = req.body;
  try {
    const hotel = await pool.query('SELECT id FROM hoteles WHERE id=$1', [hotel_id]);
    if (hotel.rows.length === 0)
      return res.status(404).json({ error: 'El hotel indicado no existe.' });

    const result = await pool.query(
      `UPDATE habitaciones SET hotel_id=$1, numero=$2, tipo=$3, precio_noche=$4, estado=$5
       WHERE id=$6 RETURNING *`,
      [hotel_id, numero.trim(), tipo, precio_noche, estado || 'Disponible', id]
    );
    if (result.rows.length === 0)
      return res.status(404).json({ error: 'Habitación no encontrada.' });
    res.json(result.rows[0]);
  } catch (err) {
    if (err.code === '23505')
      return res.status(400).json({ error: 'Ya existe una habitación con ese número en el hotel.' });
    console.error(err);
    res.status(500).json({ error: 'Error de conexión con la base de datos.' });
  }
});

router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  if (isNaN(Number(id))) return res.status(400).json({ error: 'El ID debe ser numérico.' });
  try {
    const result = await pool.query('DELETE FROM habitaciones WHERE id=$1 RETURNING *', [id]);
    if (result.rows.length === 0)
      return res.status(404).json({ error: 'Habitación no encontrada.' });
    res.json({ mensaje: 'Habitación eliminada correctamente.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error de conexión con la base de datos.' });
  }
});

module.exports = router;
